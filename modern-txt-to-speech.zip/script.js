// Get necessary elements from the DOM
const textArea = document.querySelector("#text");
const formatSelect = document.querySelector("#format");
const convertBtn = document.querySelector("#convert-btn");
const downloadLink = document.querySelector("#download-link");
const voiceSelect = document.querySelector("#voices");

// Load available voices when the page is ready
window.addEventListener("DOMContentLoaded", () => {
  loadVoices();
});

// Load available voices
function loadVoices() {
  const voices = window.speechSynthesis.getVoices();
  voices.forEach((voice) => {
    const option = document.createElement("option");
    option.value = voice.name;
    option.textContent = `${voice.name} (${voice.lang})`;
    voiceSelect.appendChild(option);
  });
}

// Convert text to speech and download the output file
convertBtn.addEventListener("click", () => {
  const text = textArea.value;
  const format = formatSelect.value;
  const voice = voiceSelect.value;
  const utterance = new SpeechSynthesisUtterance(text);
  const voices = window.speechSynthesis.getVoices();
  const selectedVoice = voices.find((v) => v.name === voice);
  utterance.voice = selectedVoice;
  utterance.onend = () => {
    const blob = new Blob([new Uint8Array(0)]);
    const extension = format === "mp3" ? "mpeg" : format;
    const url = URL.createObjectURL(blob);
    downloadLink.href = `${url}/output.${extension}`;
    downloadLink.download = `output.${format}`;
    downloadLink.click();
  };
  window.speechSynthesis.speak(utterance);
});
