// Get references to the HTML elements we'll be working with
const fileInput = document.getElementById('file');
const convertBtn = document.getElementById('convert-btn');
const transcriptDiv = document.getElementById('transcript');
const transcriptText = document.getElementById('transcript-text');

// Attach a click event listener to the convert button
convertBtn.addEventListener('click', () => {
  // Check if a file has been selected
  if (fileInput.files.length > 0) {
    // If a file has been selected, create a new webkitSpeechRecognition object
    const file = fileInput.files[0];
    const recognition = new webkitSpeechRecognition();
    // Set the language to US English
    recognition.lang = 'en-US';
    // Set the audio file to the selected file
    recognition.setAudioFile(file);
    // Start the recognition process
    recognition.start();
    // When recognition is complete, display the transcript text
    recognition.onresult = event => {
      const transcript = event.results[0][0].transcript;
      transcriptText.textContent = transcript;
      transcriptDiv.classList.remove('hidden');
    };
    // If an error occurs during recognition, log the error to the console and display an error message
    recognition.onerror = event => {
      console.error('Error occurred while converting speech to text:', event.error);
      transcriptText.textContent = 'An error occurred while converting speech to text. Please try again.';
      transcriptDiv.classList.remove('hidden');
    };
  } else {
    // If no file has been selected, display a warning message
    console.warn('No file selected.');
    transcriptText.textContent = 'Please select a file to convert to text.';
    transcriptDiv.classList.remove('hidden');
  }
});

// Check if the Web Speech API is supported in the browser
if (!('webkitSpeechRecognition' in window)) {
  console.warn('Web Speech API is not supported in this browser.');
  transcriptText.textContent = 'Sorry, the speech-to-text feature is not supported in your browser.';
  transcriptDiv.classList.remove('hidden');
}
